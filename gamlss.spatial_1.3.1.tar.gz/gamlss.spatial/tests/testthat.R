library(testthat)
library(gamlss.spatial)

test_check("gamlss.spatial")
